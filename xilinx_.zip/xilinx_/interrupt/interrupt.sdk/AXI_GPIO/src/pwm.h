/*
 * pwm.h
 *
 *  Created on: 2019��11��11��
 *      Author: ma
 */

#ifndef SRC_PWM_H_
#define SRC_PWM_H_

#include "stdio.h"
#include "xparameters.h"
#include "pwm_ip.h"
#include "sleep.h"
#include "xil_io.h"

void pwm0(long int fre, double duty);
void pwm1(long int fre, double duty);
void pwm2(long int fre, double duty);
void pwm3(long int fre, double duty);
void pwm4(long int fre, double duty);
void pwm5(long int fre, double duty);
void pwm6(long int fre, double duty);
void pwm7(long int fre, double duty);

#endif /* SRC_PWM_H_ */
