/*
 * robot.h
 *
 *  Created on: 2019��11��15��
 *      Author: ma
 */

#ifndef SRC_ROBOT_H_
#define SRC_ROBOT_H_

#include "pwm.h"

#define awlaysgoforward   70
#define awlaysgobackward  21
#define goforward   25
#define gobackward   28
#define goleftward   12
#define gorightward   94
#define gotoleft   68
#define gotoright   67

void forward(void);
void backward(void);
void leftward(void);
void rightward(void);
void goleft(void);
void goright(void);
void start(void);

#endif /* SRC_ROBOT_H_ */
