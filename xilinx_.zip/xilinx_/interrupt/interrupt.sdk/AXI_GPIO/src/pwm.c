/*
 * pwm.c
 *
 *  Created on: 2019��11��11��
 *      Author: ma
 */

#include "pwm.h"

void pwm0(long int fre, double duty) {
	int counter;
	counter = (fre + 1) * duty / 100;
	PWM_IP_mWriteReg(XPAR_PWM_IP_0_S00_AXI_BASEADDR,
			PWM_IP_S00_AXI_SLV_REG0_OFFSET, fre);
	PWM_IP_mWriteReg(XPAR_PWM_IP_0_S00_AXI_BASEADDR,
			PWM_IP_S00_AXI_SLV_REG1_OFFSET, counter);
}
void pwm1(long int fre, double duty) {
	long int counter;
	counter = (fre + 1) * duty / 100;
	PWM_IP_mWriteReg(XPAR_PWM_IP_0_S00_AXI_BASEADDR,
			PWM_IP_S00_AXI_SLV_REG2_OFFSET, fre);
	PWM_IP_mWriteReg(XPAR_PWM_IP_0_S00_AXI_BASEADDR,
			PWM_IP_S00_AXI_SLV_REG3_OFFSET, counter);
}
void pwm2(long int fre, double duty) {
	long int counter;
	counter = (fre + 1) * duty / 100;
	PWM_IP_mWriteReg(XPAR_PWM_IP_0_S00_AXI_BASEADDR,
			PWM_IP_S00_AXI_SLV_REG4_OFFSET, fre);
	PWM_IP_mWriteReg(XPAR_PWM_IP_0_S00_AXI_BASEADDR,
			PWM_IP_S00_AXI_SLV_REG5_OFFSET, counter);
}
void pwm3(long int fre, double duty) {
	long int counter;
	counter = (fre + 1) * duty / 100;
	PWM_IP_mWriteReg(XPAR_PWM_IP_0_S00_AXI_BASEADDR,
			PWM_IP_S00_AXI_SLV_REG6_OFFSET, fre);
	PWM_IP_mWriteReg(XPAR_PWM_IP_0_S00_AXI_BASEADDR,
			PWM_IP_S00_AXI_SLV_REG7_OFFSET, counter);
}
void pwm4(long int fre, double duty) {
	long int counter;
	counter = (fre + 1) * duty / 100;
	PWM_IP_mWriteReg(XPAR_PWM_IP_0_S00_AXI_BASEADDR,
			PWM_IP_S00_AXI_SLV_REG8_OFFSET, fre);
	PWM_IP_mWriteReg(XPAR_PWM_IP_0_S00_AXI_BASEADDR,
			PWM_IP_S00_AXI_SLV_REG9_OFFSET, counter);
}
void pwm5(long int fre, double duty) {
	long int counter;
	counter = (fre + 1) * duty / 100;
	PWM_IP_mWriteReg(XPAR_PWM_IP_0_S00_AXI_BASEADDR,
			PWM_IP_S00_AXI_SLV_REG10_OFFSET, fre);
	PWM_IP_mWriteReg(XPAR_PWM_IP_0_S00_AXI_BASEADDR,
			PWM_IP_S00_AXI_SLV_REG11_OFFSET, counter);
}
void pwm6(long int fre, double duty) {
	long int counter;
	counter = (fre + 1) * duty / 100;
	PWM_IP_mWriteReg(XPAR_PWM_IP_0_S00_AXI_BASEADDR,
			PWM_IP_S00_AXI_SLV_REG12_OFFSET, fre);
	PWM_IP_mWriteReg(XPAR_PWM_IP_0_S00_AXI_BASEADDR,
			PWM_IP_S00_AXI_SLV_REG13_OFFSET, counter);
}
void pwm7(long int fre, double duty) {
	long int counter;
	counter = (fre + 1) * duty / 100;
	PWM_IP_mWriteReg(XPAR_PWM_IP_0_S00_AXI_BASEADDR,
			PWM_IP_S00_AXI_SLV_REG14_OFFSET, fre);
	PWM_IP_mWriteReg(XPAR_PWM_IP_0_S00_AXI_BASEADDR,
			PWM_IP_S00_AXI_SLV_REG15_OFFSET, counter);
}
